package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.EmailOtp;
import com.example.demo.repository.EmailOtpRepository;

@Service
public class EmailOtpService {
	@Autowired
	private EmailOtpRepository emailotprepo;
	public String addEmail(EmailOtp emailotp) {
		if(emailotprepo.save(emailotp)!= null) 
			return"OTP sent Successfully";
		return "Something wrong";
	}
	public List<EmailOtp> getEmailOtp(String email){
		List<EmailOtp> emailotp=emailotprepo.findByEmail(email);
		return emailotp;
	}
}
