package com.example.demo.controller;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.config.EmailSenderService;
import com.example.demo.model.EmailOtp;
import com.example.demo.service.EmailOtpService;

import jakarta.mail.MessagingException;

@RestController
@RequestMapping("/emailservice")
public class EmailController {
	@Autowired
	private EmailOtpService emailservice;
	@Autowired
	private EmailSenderService emailsenderservice;
	@RequestMapping("/sendOtp/{email}")
	public String sendOtp(@PathVariable String email) throws MessagingException {
		String otp=generateotp();
		String to=email;
		String subject="OTP verification for your email account";
		String body="Your OTP "+otp;
		emailsenderservice.sendEmail(to, subject, body);
		EmailOtp emailotp=new EmailOtp();
		emailotp.setEmail(email);
		emailotp.setOtp(otp);
		return emailservice.addEmail(emailotp);
	}
	public static String generateotp() {
		String num="0123456789";
		String otp;
		Random random=new Random();
		char[] ch=new char[6];
		for(int i=0;i<ch.length;i++) {
			ch[i]=num.charAt(random.nextInt(num.length()));
		}
		otp=new String(ch);
		return otp;
	}
	@RequestMapping("/VerifyingOTP")
	public String verifyingOtp(@RequestBody EmailOtp emailotp) {
		String email=emailotp.getEmail();
		String otp=emailotp.getOtp();
		List<EmailOtp> db_emailotp=emailservice.getEmailOtp(email);
		for(EmailOtp eotp:db_emailotp) {
			if(eotp.getOtp().equals(otp)) {
				return "OTP verified successfully";
			}
		}
		return "OTP not verified";
	}
}
