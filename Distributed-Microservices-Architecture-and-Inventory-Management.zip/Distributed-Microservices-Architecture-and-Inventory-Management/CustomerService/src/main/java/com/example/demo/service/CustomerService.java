package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerrepo;
	public String addCustomer( Customer customer) {
		if(customerrepo.save(customer)!=null) 
			return "Registration Successfull"; 
		return "Something wrong";
	}
	public String deleteCustomerById(int id) {
		customerrepo.deleteById(id);
		return "Customer deleted successfully";
	}
	
}
