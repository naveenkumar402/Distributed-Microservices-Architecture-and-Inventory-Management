package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productrepo;
	public String addProduct(Product product) {
		if(productrepo.save(product)!=null)
			return "Book was added";
		return "Bookwas not added";
	}
	public String deleteProduct(Product product) {
		try {
			productrepo.delete(product);
		}
		catch(Exception e) {
			return e.getMessage();
		}
		return "Deleted successfuly";
	}
	public List<Product> getAllProduct(){
		List<Product> product=productrepo.findAll();
		return product;
	}
	public String deleteProductById(int id) {
		productrepo.deleteById(id);
		return "product deleted";
	}
}
